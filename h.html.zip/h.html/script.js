function getWeather() {
    const city = document.getElementById('cityInput').value.trim();
    const apiKey = '0d732d822ea7d049584b24a5869e6177';  // Your activated API key

    if (city === '') {
        document.getElementById('weatherResult').innerHTML = '<p style="color:red">Please enter a city name.</p>';
        return;
    }

    const url = `https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(city)}&appid=${apiKey}&units=metric`;

    fetch(url)
        .then(response => response.json())
        .then(data => {
            if (data.cod === 200) {
                document.getElementById('weatherResult').innerHTML = `
                    <p><strong>City:</strong> ${data.name}</p>
                    <p><strong>Temperature:</strong> ${data.main.temp} °C</p>
                    <p><strong>Humidity:</strong> ${data.main.humidity}%</p>
                    <p><strong>Weather:</strong> ${data.weather[0].description}</p>
                `;
            } else {
                document.getElementById('weatherResult').innerHTML = `<p style="color:red">${data.message}</p>`;
            }
        })
        .catch(() => {
            document.getElementById('weatherResult').innerHTML = '<p style="color:red">Unable to fetch data!</p>';
        });
}